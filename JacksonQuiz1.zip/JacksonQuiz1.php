<?php
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$device = $_POST['device'];
$imei = $_POST['imei'];

function isValidIMEI($imei) {
    if (!ctype_digit($imei) || strlen($imei) != 15) return false;
    $sum = 0;
    for ($i = 0; $i < 14; $i++) {
        $digit = (int)$imei[$i];
        if ($i % 2 != 0) {
            $digit *= 2;
            if ($digit > 9) $digit -= 9;
        }
        $sum += $digit;
    }
    $checkDigit = (10 - ($sum % 10)) % 10;
    return $checkDigit == (int)$imei[14];
}

function getRBIGroup($imei) {
    $rbi = substr($imei, 0, 2);
    $groups = [
        '01' => 'PTCRB (United States)',
        '35' => 'BABT (United Kingdom)',
        '86' => 'TAF (China)',
        '91' => 'TUV (Germany)',
        '98' => 'CETECOM (Korea)'
    ];
    return $groups[$rbi] ?? 'Unknown Region';
}

$validIMEI = isValidIMEI($imei) ? "Valid IMEI ✅" : "Invalid IMEI ❌";
$rbiGroup = getRBIGroup($imei);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Verizon Order Confirmation</title>
<style>
  body { font-family: Arial; background: #f4f4f4; padding: 20px; }
  h2 { color: #d60000; }
  p { font-size: 16px; }
</style>
</head>
<body>

<h2>Verizon Device Order Confirmation</h2>

<p><strong>Name:</strong> <?php echo htmlspecialchars($name); ?></p>
<p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
<p><strong>Phone:</strong> <?php echo htmlspecialchars($phone); ?></p>
<p><strong>Device Selected:</strong> <?php echo htmlspecialchars($device); ?></p>

<hr>
<p><strong>IMEI Entered:</strong> <?php echo htmlspecialchars($imei); ?></p>
<p><strong>Status:</strong> <?php echo $validIMEI; ?></p>
<p><strong>RBI Group:</strong> <?php echo $rbiGroup; ?></p>

<?php
echo "<hr/>Last Modified: " . strftime('%a, %b %d, %Y at %I:%M %p', filemtime($_SERVER['SCRIPT_FILENAME']));
?>

</body>
</html>